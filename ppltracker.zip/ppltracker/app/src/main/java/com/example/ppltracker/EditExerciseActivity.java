package com.example.ppltracker;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;

public class EditExerciseActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private EditText edtExerciseName;
    private String routine;
    private int exerciseId;
    private EditText edtReps;
    private EditText edtSets;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_exercise);

        dbHelper = new DatabaseHelper(this);
        routine = getIntent().getStringExtra("routine");
        exerciseId = getIntent().getIntExtra("exerciseId", -1);
        edtReps = findViewById(R.id.etReps);
        edtSets = findViewById(R.id.etSets);
        edtExerciseName = findViewById(R.id.etExerciseName);

        if (exerciseId != -1) {
            Exercise exercise = dbHelper.getExerciseById(exerciseId);
            edtExerciseName.setText(exercise.getName());

            String[] repsSets = exercise.getRepsSets().split("x");
            edtReps.setText(repsSets[0]);
            edtSets.setText(repsSets[1]);
        }

        Button btnSave = findViewById(R.id.btnSave);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String exerciseName = edtExerciseName.getText().toString();
                String reps = edtReps.getText().toString();
                String sets = edtSets.getText().toString();

                if (exerciseName.isEmpty() || reps.isEmpty() || sets.isEmpty()) {
                    Toast.makeText(EditExerciseActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else if (exerciseName.length() > 20 ||reps.length() > 20 || sets.length() > 20) {
                    Toast.makeText(EditExerciseActivity.this, "Reps or Sets input is too long. It should not exceed 20 characters.", Toast.LENGTH_SHORT).show();
                    return;
                }else{
                    Exercise exercise = new Exercise(0, exerciseName, reps, sets, routine);
                    if (exerciseId == -1) {
                        dbHelper.addExercise(exercise);
                    } else {
                        dbHelper.updateExercise(exercise);
                    }

                    setResult(RESULT_OK);
                    finish();
                }
            }
        });

        Button btnCancel = findViewById(R.id.btnCancel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
