package com.example.ppltracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "PPLTracker.db";
    private static final int DATABASE_VERSION = 11;

    private static final String TABLE_EXERCISES = "exercises";
    private static final String EXERCISE_ID = "id";
    private static final String EXERCISE_NAME = "name";
    private static final String EXERCISE_REPS = "reps";
    private static final String EXERCISE_SETS = "sets";
    private static final String EXERCISE_ROUTINE = "routine";

    private static final String TABLE_WEIGHT_ENTRIES = "weight_entries";
    private static final String WEIGHT_ID = "id";
    private static final String WEIGHT_EXERCISE_ID = "exercise_id";
    private static final String WEIGHT_WEIGHT = "weight";
    private static final String WEIGHT_REPS = "reps";
    private static final String WEIGHT_DATE = "date";

    public static final String WEIGHT_ENTRY_TABLE = "weight_entries";
    private static final String WEIGHT_TIMESTAMP = "timestamp";
    private static final String WEIGHT_SETS = "sets";
    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_EXERCISE_TABLE = "CREATE TABLE " + TABLE_EXERCISES + "("
                + EXERCISE_ID + " INTEGER PRIMARY KEY," + EXERCISE_NAME + " TEXT,"
                + EXERCISE_REPS + " TEXT," + EXERCISE_SETS + " TEXT,"
                + EXERCISE_ROUTINE + " TEXT" + ")";
        db.execSQL(CREATE_EXERCISE_TABLE);

        String CREATE_WEIGHT_ENTRY_TABLE = "CREATE TABLE " + TABLE_WEIGHT_ENTRIES + "("
                + WEIGHT_ID + " INTEGER PRIMARY KEY," + WEIGHT_EXERCISE_ID + " INTEGER,"
                + WEIGHT_WEIGHT + " REAL," + WEIGHT_REPS + " INTEGER," + WEIGHT_SETS + " INTEGER,"
                + WEIGHT_DATE + " TEXT," + WEIGHT_TIMESTAMP + " INTEGER,"
                + "FOREIGN KEY(" + WEIGHT_EXERCISE_ID + ") REFERENCES " + TABLE_EXERCISES + "(" + EXERCISE_ID + "))";
        db.execSQL(CREATE_WEIGHT_ENTRY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXERCISES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT_ENTRIES);
        onCreate(db);
    }

    public void addExercise(Exercise exercise) {
        SQLiteDatabase db = this.getWritableDatabase();

        String reps = exercise.getReps();
        String sets = exercise.getSets();
        if (reps.length() > 20 || sets.length() > 20) {
            throw new IllegalArgumentException("Reps or Sets input is too long. It should not exceed 20 characters.");
        }

        ContentValues values = new ContentValues();
        values.put(EXERCISE_NAME, exercise.getName());
        values.put(EXERCISE_REPS, reps);
        values.put(EXERCISE_SETS, sets);
        values.put(EXERCISE_ROUTINE, exercise.getRoutine());

        db.insert(TABLE_EXERCISES, null, values);
        db.close();
    }


    public void updateExercise(Exercise exercise) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EXERCISE_NAME, exercise.getName());
        contentValues.put(EXERCISE_ROUTINE, exercise.getRoutine());
        contentValues.put(EXERCISE_REPS, exercise.getReps());
        contentValues.put(EXERCISE_SETS, exercise.getSets());
        db.update(TABLE_EXERCISES, contentValues, EXERCISE_ID + " = ?", new String[]{String.valueOf(exercise.getId())});
        db.close();
    }

    public void deleteExercise(int exerciseId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_EXERCISES, EXERCISE_ID + " = ?", new String[]{String.valueOf(exerciseId)});
        db.close();
    }

    public Exercise getExerciseById(int exerciseId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_EXERCISES, new String[]{EXERCISE_ID, EXERCISE_NAME, EXERCISE_REPS, EXERCISE_SETS, EXERCISE_ROUTINE},
                EXERCISE_ID + " = ?", new String[]{String.valueOf(exerciseId)}, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        Exercise exercise = new Exercise(
                cursor.getInt(0),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3),
                cursor.getString(4));
        cursor.close();
        return exercise;
    }

    public void addWeightEntry(WeightEntry weightEntry) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WEIGHT_SETS, weightEntry.getSets());
        values.put(WEIGHT_EXERCISE_ID, weightEntry.getExerciseId());
        values.put(WEIGHT_WEIGHT, weightEntry.getWeight());
        values.put(WEIGHT_REPS, weightEntry.getReps());
        values.put(WEIGHT_DATE, weightEntry.getDate());
        values.put(WEIGHT_TIMESTAMP, System.currentTimeMillis()); // add this line
        db.insert(TABLE_WEIGHT_ENTRIES, null, values);
        db.close();
    }

    public int updateWeightEntry(WeightEntry weightEntry) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(WEIGHT_SETS, weightEntry.getSets());
        values.put(WEIGHT_EXERCISE_ID, weightEntry.getExerciseId());
        values.put(WEIGHT_WEIGHT, weightEntry.getWeight());
        values.put(WEIGHT_REPS, weightEntry.getReps());
        values.put(WEIGHT_DATE, weightEntry.getDate());
        values.put(WEIGHT_TIMESTAMP, System.currentTimeMillis()); // add this line
        return db.update(TABLE_WEIGHT_ENTRIES, values, WEIGHT_ID + " = ?", new String[]{String.valueOf(weightEntry.getId())});
    }

    public void deleteWeightEntry(int weightEntryId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_WEIGHT_ENTRIES, WEIGHT_ID + " = ?", new String[]{String.valueOf(weightEntryId)});
        db.close();
    }

    public WeightEntry getWeightEntryById(int weightEntryId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_WEIGHT_ENTRIES, new String[]{WEIGHT_ID, WEIGHT_WEIGHT, WEIGHT_REPS, WEIGHT_DATE, WEIGHT_EXERCISE_ID},
                WEIGHT_ID + " = ?", new String[]{String.valueOf(weightEntryId)}, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        WeightEntry weightEntry = new WeightEntry(
                cursor.getInt(cursor.getColumnIndex(WEIGHT_ID)),
                cursor.getInt(cursor.getColumnIndex(WEIGHT_EXERCISE_ID)),
                cursor.getDouble(cursor.getColumnIndex(WEIGHT_WEIGHT)),
                cursor.getInt(cursor.getColumnIndex(WEIGHT_REPS)),
                cursor.getInt(cursor.getColumnIndex(WEIGHT_SETS)),
                cursor.getString(cursor.getColumnIndex(WEIGHT_DATE)),
                cursor.getLong(cursor.getColumnIndex(WEIGHT_TIMESTAMP)));
        cursor.close();
        return weightEntry;
    }

    public List<WeightEntry> getAllWeightEntries() {
        List<WeightEntry> weightEntries = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_WEIGHT_ENTRIES;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                WeightEntry weightEntry = new WeightEntry(
                        cursor.getInt(cursor.getColumnIndex(WEIGHT_ID)),
                        cursor.getInt(cursor.getColumnIndex(WEIGHT_EXERCISE_ID)),
                        cursor.getDouble(cursor.getColumnIndex(WEIGHT_WEIGHT)),
                        cursor.getInt(cursor.getColumnIndex(WEIGHT_REPS)),
                        cursor.getInt(cursor.getColumnIndex(WEIGHT_SETS)),
                        cursor.getString(cursor.getColumnIndex(WEIGHT_DATE)),
                        cursor.getLong(cursor.getColumnIndex(WEIGHT_TIMESTAMP)));
                weightEntries.add(weightEntry);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return weightEntries;
    }

    public List<Exercise> getAllExercises() {
        List<Exercise> exercises = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_EXERCISES;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Exercise exercise = new Exercise(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4));
                exercises.add(exercise);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return exercises;
    }
    public List<WeightEntry> getWeightEntriesByExerciseId(int exerciseId) {
        List<WeightEntry> weightEntryList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT  * FROM " + TABLE_WEIGHT_ENTRIES + " WHERE " + WEIGHT_EXERCISE_ID + " = " + exerciseId + " ORDER BY " + WEIGHT_TIMESTAMP + " DESC";

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(WEIGHT_ID));
                double weight = cursor.getDouble(cursor.getColumnIndex(WEIGHT_WEIGHT));
                int reps = cursor.getInt(cursor.getColumnIndex(WEIGHT_REPS));
                String date = cursor.getString(cursor.getColumnIndex(WEIGHT_DATE));

                WeightEntry weightEntry = new WeightEntry(
                        id,
                        exerciseId,
                        weight,
                        reps,
                        cursor.getInt(cursor.getColumnIndex(WEIGHT_SETS)),
                        date,
                        cursor.getLong(cursor.getColumnIndex(WEIGHT_TIMESTAMP)));
                weightEntryList.add(weightEntry);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return weightEntryList;
    }

    public List<Exercise> getExercisesWithLatestWeightEntries(String routine) {
        List<Exercise> exerciseList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT " + EXERCISE_ID + ", " + EXERCISE_NAME + ", " + EXERCISE_REPS + ", " + EXERCISE_SETS +
                " FROM " + TABLE_EXERCISES +
                " WHERE " + EXERCISE_ROUTINE + " = '" + routine + "'";

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(EXERCISE_ID));
                String name = cursor.getString(cursor.getColumnIndex(EXERCISE_NAME));
                String reps = cursor.getString(cursor.getColumnIndex(EXERCISE_REPS));
                String sets = cursor.getString(cursor.getColumnIndex(EXERCISE_SETS));

                Exercise exercise = new Exercise(id, name, reps, sets, routine);
                WeightEntry latestWeightEntry = getLatestWeightEntryByExerciseId(id);
                exercise.setLatestWeightEntry(latestWeightEntry);
                exerciseList.add(exercise);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return exerciseList;
    }
    public List<Exercise> getExercisesWithRepsAndSets(String routine) {
        List<Exercise> exerciseList = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();
        String selectQuery = "SELECT  * FROM " + TABLE_EXERCISES +
                " WHERE " + EXERCISE_ROUTINE + " = '" + routine + "'";

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex(EXERCISE_ID));
                String name = cursor.getString(cursor.getColumnIndex(EXERCISE_NAME));
                String reps = cursor.getString(cursor.getColumnIndex(EXERCISE_REPS));
                String sets = cursor.getString(cursor.getColumnIndex(EXERCISE_SETS));

                Exercise exercise = new Exercise(id, name, reps, sets, routine);

                WeightEntry latestWeightEntry = getLatestWeightEntryByExerciseId(id);
                if (latestWeightEntry != null) {
                    exercise.setLatestWeightEntry(latestWeightEntry);
                }

                exerciseList.add(exercise);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return exerciseList;
    }
    public WeightEntry getLatestWeightEntryByExerciseId(int exerciseId) {
        SQLiteDatabase db = this.getReadableDatabase();

        String selectQuery = "SELECT " + WEIGHT_ID + ", " + WEIGHT_EXERCISE_ID + ", " + WEIGHT_WEIGHT + ", " + WEIGHT_REPS + ", " + WEIGHT_DATE +
                " FROM " + TABLE_WEIGHT_ENTRIES +
                " WHERE " + WEIGHT_EXERCISE_ID + " = " + exerciseId +
                " ORDER BY " + WEIGHT_DATE + " DESC LIMIT 1";

        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            int id = cursor.getInt(cursor.getColumnIndex(WEIGHT_ID));
            int exercise_id = cursor.getInt(cursor.getColumnIndex(WEIGHT_EXERCISE_ID));
            double weight = cursor.getDouble(cursor.getColumnIndex(WEIGHT_WEIGHT));
            int reps = cursor.getInt(cursor.getColumnIndex(WEIGHT_REPS));
            String date = cursor.getString(cursor.getColumnIndex(WEIGHT_DATE));

            WeightEntry weightEntry = new WeightEntry(
                    id,
                    exercise_id,
                    weight,
                    reps,
                    cursor.getInt(cursor.getColumnIndex(WEIGHT_SETS)),
                    date,
                    cursor.getLong(cursor.getColumnIndex(WEIGHT_TIMESTAMP)));
            cursor.close();
            return weightEntry;
        } else {
            cursor.close();
            return null;
        }
    }



}

