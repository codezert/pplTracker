package com.example.ppltracker;

public class WeightEntry {
    private int id;
    private int exerciseId;
    private double weight;
    private int reps;
    private int sets;  // New variable for sets
    private String date;
    private long timestamp;

    public WeightEntry(int id, int exerciseId, double weight, int reps, int sets, String date, long timestamp) {
        this.id = id;
        this.exerciseId = exerciseId;
        this.weight = weight;
        this.reps = reps;
        this.sets = sets;  // Initialize sets
        this.date = date;
        this.timestamp = timestamp;
    }
    // add a getter and setter for the timestamp
    public long getTimestamp() {
        return this.timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getExerciseId() {
        return exerciseId;
    }

    public void setExerciseId(int exerciseId) {
        this.exerciseId = exerciseId;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public int getReps() {
        return reps;
    }

    public void setReps(int reps) {
        this.reps = reps;
    }

    public int getSets() {
        return sets;
    }

    public void setSets(int sets) {
        this.sets = sets;
    }
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
    @Override
    public String toString() {
        return "WeightEntry{" +
                "id=" + id +
                ", exerciseId=" + exerciseId +
                ", weight=" + weight +
                ", reps=" + reps +
                ", sets=" + sets +  // Add sets here
                ", date='" + date + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}