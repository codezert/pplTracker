package com.example.ppltracker;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import android.widget.Toast;

public class ExerciseDetailsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WeightEntryAdapter weightEntryAdapter;
    private List<WeightEntry> weightEntryList;
    private DatabaseHelper dbHelper;
    private int exerciseId;
    private Exercise exercise;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise_details);
        final EditText edtReps = findViewById(R.id.edtReps);
        final EditText edtSets = findViewById(R.id.edtSets);
        final EditText edtWeight = findViewById(R.id.edtWeight);
        recyclerView = findViewById(R.id.recyclerViewWeightEntries);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        Button btnAddWeight = findViewById(R.id.btnSaveWeight);
        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        dbHelper = new DatabaseHelper(this);

        Intent intent = getIntent();
        exerciseId = intent.getIntExtra("exerciseId", -1);

        updateWeightEntryList();

        exercise = dbHelper.getExerciseById(exerciseId);
        btnAddWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weightText = edtWeight.getText().toString();
                if (weightText.isEmpty()) {
                    Toast.makeText(ExerciseDetailsActivity.this, "Please enter weight", Toast.LENGTH_SHORT).show();
                    return;
                }
                String setsText = edtSets.getText().toString();
                if (setsText.isEmpty()) {
                    Toast.makeText(ExerciseDetailsActivity.this, "Please enter sets", Toast.LENGTH_SHORT).show();
                    return;
                }
                String repsText = edtReps.getText().toString();
                if (repsText.isEmpty()) {
                    Toast.makeText(ExerciseDetailsActivity.this, "Please enter reps", Toast.LENGTH_SHORT).show();
                    return;
                }
                if ((weightText.length() > 5)||(repsText.length() > 5)||(setsText.length() > 5)) {
                    Toast.makeText(ExerciseDetailsActivity.this, "Values are too large.", Toast.LENGTH_SHORT).show();
                    return;
                }
                float weight = Float.parseFloat(weightText);
                int sets = Integer.parseInt(setsText);
                int reps = Integer.parseInt(repsText);
                String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
                WeightEntry weightEntry = new WeightEntry(-1, exerciseId, (double) weight, reps, sets, date, System.currentTimeMillis());
                dbHelper.addWeightEntry(weightEntry);
                edtWeight.setText("");
                edtSets.setText("");
                edtReps.setText("");
                updateWeightEntryList();
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void updateWeightEntryList() {
        weightEntryList = dbHelper.getWeightEntriesByExerciseId(exerciseId);
        weightEntryAdapter = new WeightEntryAdapter(this, weightEntryList);
        recyclerView.setAdapter(weightEntryAdapter);
    }
}

