package com.example.ppltracker;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btnPush, btnPull, btnLegs;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPush = findViewById(R.id.btnPush);
        btnPull = findViewById(R.id.btnPull);
        btnLegs = findViewById(R.id.btnLegs);

        btnPush.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ExerciseListActivity.class);
                intent.putExtra("routine", "Push");
                startActivity(intent);
            }
        });

        btnPull.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ExerciseListActivity.class);
                intent.putExtra("routine", "Pull");
                startActivity(intent);
            }
        });

        btnLegs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ExerciseListActivity.class);
                intent.putExtra("routine", "Legs");
                startActivity(intent);
            }
        });
        dbHelper = new DatabaseHelper(this);

        // Check if the exercises have already been added
        if (dbHelper.isExercisesEmpty()) {
            dbHelper.createDefaultWorkouts();
        }
    }
}
